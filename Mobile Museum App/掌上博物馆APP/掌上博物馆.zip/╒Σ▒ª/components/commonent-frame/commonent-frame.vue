<template>
	<view>
		<view class="commentFrame">
			<uni-easyinput ref="uipt" @confirm="goComment" suffixIcon="paperplane" v-model="replyContent"
				:placeholder="placeholder" @iconClick="goComment">
			</uni-easyinput>
		</view>
	</view>
</template>

<script>
	const db=uniCloud.database()
	export default {
		name: "commonent-frame",
		props:{
			commentObj:Object,
			adb:[String,Number,Object]
		},
		data() {
			return {
				replyContent:'',
				placeholder:'输入评论吧'
			};
		},
		methods:{
			goComment(){
				console.log(this.adb);
				db.collection("dongtai_commonent").add({
					"comment_content":this.replyContent,
					"comment_type":0,
					...this.commentObj
				}).then(res=>{
					console.log(res);
				})
			}
		}
	}
</script>

<style lang="scss" scoped>
	.commentFrame {
		width: 100%;
		background: #fff;
		padding: 20rpx 30rpx;
		box-sizing: border-box;
		position: fixed;
		bottom: 0;
		left: 0;
		z-index: 100;
	}
</style>
