<template>
	<view>
		<view class="fixed-top" style="background-color: #AC9162;">
			<!-- 自定义导航栏 -->
			<uniStatusBar></uniStatusBar>
			<view style="height: 44px;border-top-left-radius: 15rpx;border-top-right-radius: 15rpx;" class="flex border-bottom align-center">
				<view class=" flex ml-2" style="flex: 8;">
					<slot name="left"></slot>
					
				</view>
				<view class=" flex justify-center" style="flex: 2;">
					<slot name="content"></slot>
				</view>
				<!-- <view class="flex-1 flex justify-end">
					<slot name="right"></slot>
					
				</view> -->
			</view>
		</view>
		<view>
			<uniStatusBar></uniStatusBar>
			<view style="height: 44px;"></view>
		</view>
	</view>
</template>

<script>
	import uniStatusBar from '../../components/uni-ui/uni-status-bar/uni-status-bar.vue'
	export default {
		components:{
			uniStatusBar
		},
		name:"navBar",
		data() {
			return {
				
			};
		}
	}
</script>

<style>

</style>