<template>
	<view>
		<view style="width: 95%;border-radius: 20rpx;height: 400rpx;margin: 20rpx auto;background-color: #fff;" class=" flex flex-column" v-for="(item,index) in list" @click="goDetail(item._id)">
			<view style="flex: 3;" v-for="(pic,index) in item.picurls">
				<image :src="pic" style="width: 100%;height: 100%;"  mode=""></image>
			</view>
			<view style="flex: 1;">
				<view style="width: 90%;margin: 0 auto;">
					<view>
						<view><text>{{item.title}}|</text>{{item.description}}</view>
					</view>
					<view>
						<view><text>{{item.user_id[0].username}}</text></view>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	const db=uniCloud.database()
	export default {
		data() {
			return {
				list:[],
				data:''
		
			}
		},
		onLoad() {
			
			this.getData()
		},
		methods: {
			// 跳转到详情页面
			goDetail(id){
				uni.navigateTo({
					url:'/pages/detail2/detail2?id='+id
				})
			},
			// 获取数据
			getData(){
				let artTemp=db.collection("user_articles").getTemp()
				let userTemp=db.collection("uni-id-users").field("_id,username").getTemp()
				db.collection(artTemp,userTemp).get().then(res=>{
					this.list=res.result.data
				
				})
				db.collection("user_articles").get().then(res=>{
					this.list=res.result.data
					
				})
			}
		}
	}
</script>

<style>
page {
		width: 100%;
		height: 100%;
		background-color: #F0EFF4;
	}
</style>
