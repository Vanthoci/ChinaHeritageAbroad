<template>
	<view>
		<view class="detail">
			<view class="container">
				<view class="title">{{list.title}}</view>
				<view class="userinfo">
					<view class="avatar">
						<image src="../../static/logo.png" mode="aspectFill"></image>
					</view>
					<view class="text">
						<view class="name">{{username}}</view>
						<view class="small">
							<uni-dateformat :date="list.publish_date"></uni-dateformat>
						</view>
					</view>
				</view>
				<view class="content" style="width: 95%;margin: 0 auto;border-radius: 20rpx;">
					
					<u-parse :content="list.content" :tagStyle="tagStyle"></u-parse>
					<!-- <image :src="list.avatar" mode=""></image> -->
				</view>
				
				<view class="like">
					<view class="btn" @click="clickLike">
						<text class="iconfont icon-good-fill"></text>
						<text>{{list.like_count}}</text>
					</view>								
					<!-- <view class="users">					
						<image src="../../static/logo.png" mode="aspectFill" ></image>
					</view>				
					<view class="text"><text class="num">{{list.view_count}}</text>人看过</view> -->
				</view>
				
			</view>
			<view class="comment">
						<view>
							<u-empty
									mode="comment"
									icon="https://cdn.uviewui.com/uview/empty/comment.png"
							>
							</u-empty>
						</view>
						
						<view class="content">
							<view class="item" v-for="item in commentList">
								<comment-item :item="item"></comment-item>									
							</view>
						</view>
						
					</view>
					<commonent-frame :commentObj="commentObj" :db="db"></commonent-frame>
					<image src="https://www.lnmuseum.com.cn/singleMuseum/3DView/liaoning/2275.html" mode=""></image>
		</view>
	</view>
</template>

<script>
	const db=uniCloud.database()
	export default {
		data() {
			return {
				id:'',
				list:[],
				username:'',
				tagStyle:{
									p:"line-height:1.7em;font-size:16px;padding-bottom:10rpx",
									img:"margin:10rpx 0"
								},
								commentObj:{
									article_id:""
								},
								commentList:[],
								db:'dongtai_commonent',
								uid:''
			}
		},
		onLoad(e) {
			this.id=e.id
			this.getUser()
			this.getData()
			this.commentObj.article_id=e.id
			this.getComment()
		},
		methods: {
			getUser(){
				let id=uniCloud.getCurrentUserInfo()
				this.uid=id.uid
			},
			clickLike(){
				db.collection("dongtai_dianzan").where({
					user_id:this.uid,
					article_id:this.id
				}).count().then(res=>{
					if(res.result.total){
						db.collection("user_articles").doc(this.id).update({
							like_count:this.list.like_count-1
						}).then(res=>{
							db.collection("dongtai_dianzan").remove()
							this.getData()
						})
					}else{
						db.collection("user_articles").doc(this.id).update({
							like_count:this.list.like_count+1
						}).then(res=>{
							db.collection("dongtai_dianzan").add({
								article_id:this.id
							})
							this.getData()
						})
					}
				})
				
			},
			getComment(){
				// db.collection("zhen_commonent").where({
				// 	article_id:this.artid
				// }).limit(5).get().then(res=>{
				// 	this.commentList=res.result.data
					
				// })
				let commonentTemp=db.collection("dongtai_commonent").where({
				 	article_id:this.id
				 }).orderBy("comment_date desc").limit(5).getTemp()
				 let userTemp=db.collection("uni-id-users").field("_id,username").getTemp()
				 db.collection(commonentTemp,userTemp).get().then(res=>{
					 console.log(res);
					this.commentList=res.result.data
				 })
			},
			getData(){
				db.collection("user_articles").doc(this.id).get({
					getOne:true
				}).then(res=>{
					this.list=res.result.data
					console.log(this.list);
					
				})
			}
		}
	}
</script>

<style lang="scss">
.detail{
	background: #f8f8f8;
	min-height: calc(100vh - var(--window-top));	
	.container{
		padding:30rpx;	
		background: #fff;
		.title{
			font-size: 46rpx;
			color:#333;
			line-height: 1.4em;
			font-weight: 600;
		}
		.userinfo{
			padding:20rpx 0 50rpx;
			display: flex;
			align-items: center;
			.avatar{
				width: 60rpx;
				height: 60rpx;
				padding-right: 15rpx;
				image{
					width: 100%;
					height: 100%;
					border-radius: 50%;
				}
			}
			.text{
				font-size: 28rpx;
				color:#555;
				.small{
					font-size: 20rpx;
					color:#999;
				}
			}
		}
		.content{
			
		}
		.like{
			display: flex;
			flex-direction: column;
			align-items: center;
			padding:80rpx 50rpx 50rpx;
			.btn{
				width: 260rpx;
				height: 120rpx;
				background: #e4e4e4;
				border-radius: 100rpx;
				color:#fff;
				display: flex;
				justify-content: center;
				align-items: center;
				flex-direction: column;
				font-size: 28rpx;
				.iconfont{
					font-size: 50rpx;
				}
				&.active{
					background: #0199FE;
				}
			}
			.text{
				font-size: 26rpx;
				color:#666;				
				.num{
					color:#0199FE
				}
				.spot{
					padding:0 10rpx;
				}
			}
			.users{
				display: flex;
				justify-content: center;
				padding:30rpx 0;
				image{
					width: 50rpx;
					height: 50rpx;
					border-radius: 50%;
					border:3px solid #fff;
					margin-left:-20rpx;
				}
			}
		}
		
	}
}
</style>
