<template>
	<view>
		<!-- 自定义导航栏 -->
		<helang-compress ref="helangCompress"></helang-compress>
		<navBar>
			<u-search shape="shape" slot="left" :showAction="false" style="" @search="search" v-model="searchVal"></u-search>
			<view slot="content">
				<u-icon name="plus" color="#eee" size="23" @click="clickicon"></u-icon>
			</view>
		</navBar>
		
		<view>
			<u-popup :show="show" @close="close" @open="open" mode="top">
				<view style="height: 44px;" class="flex align-center">
					<view class="flex-1 align-center justify-center flex" @click="shibie">
						<u-icon name="photo" color="#606266" size="28"></u-icon>
					</view>
					<view class="flex-1 align-center justify-center flex" @click="shebieSrc">
						<u-icon name="photo-fill" color="#606266" size="28"></u-icon>
					</view>
				</view>
			</u-popup>

		</view>
		<view>
			<u-popup :show="show2" @close="close" @open="open" mode="bottom">
				<view style="margin-top: 44px;" class="flex align-center">
					<view v-for="(item,index) in ImgDetail" :key="index">
						<view>{{item.root}}</view>
					</view>
				</view>
			</u-popup>

		</view>
		<!-- 导航栏 -->
		<u-tabs :list="tabs" @click="click"></u-tabs>
		<!-- 轮播图 -->
		<u-swiper :list="bannerList" class="m-2"></u-swiper>
		<view>
			<video src="../../static/这是一份带你入坑的博物馆指南.mp4" autoplay="true" style="width: 100%;border-radius: 20rpx;"></video>
		</view>
		<!-- 主体部分 -->
		<view style="width: 80%;margin: 70rpx auto;height: 900rpx;background-color: #fff;border-radius: 20rpx;"
			class="flex flex-column" v-for="(item,index) in artList" :key="index" @click="goDetail(item._id)">
			<view style="flex: 7;">
				<image :src="item.avatar" style="width: 100%;height: 100%;" mode=""></image>
			</view>
			<view style="flex: 1;">
				<view style="width: 90%;margin: 0 auto;">
					<view class="font-weight-bold">{{item.title}}</view>
					<view style="color: #D9D7D8;">
						{{item.user}}
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	const db = uniCloud.database()
	import helangCompress from '@/components/helang-compress/helang-compress';
	export default {
		components: {
			helangCompress
		},
		data() {
			return {
				tabs: [{
						name: '最新'
					},
					{
						name: '精选'
					}
				],
				bannerList: [],
				artList: [],
				show: false,
				ImgDetail: [],
				show2: false,
				searchVal:''
			}
		},
		onLoad() {
			this.getBanner()
			this.getTabs()
		},
		methods: {
			search(){
							db.collection("zhen_indexarticle").where({
								title:this.searchVal
							}).get().then(res=>{
								this.artList=res.result.data
							})
						},
			clickPhoto() {
				this.ImgDetail = res.result.result
			},
			shebieSrc(id) {
				uni.navigateTo({
					url:'/pages/shibie/shibie'
				})
			},
			shibie() {
				let vm = this;
				uni.chooseImage({
					count: 1,
					success: function(resq) {
						let filePath = resq.tempFilePaths[0]
						vm.$refs.helangCompress.compress({
							src: filePath,
							maxSize: 100,
							fileType: 'jpg',
							quality: 0.1,
							minSize: -1
						}).then(resp => {
							uni.request({
								url: resp,
								method: 'GET',
								responseType: 'arraybuffer',
								success: function(res) {
									let base64s = uni.arrayBufferToBase64(res.data);
									uniCloud.callFunction({
										name: 'userShibie',
										data: {
											bas64: base64s
										}
									}).then(res => {
										uni.navigateTo({
											url: '/pages/shibie/shibie?data=' +
												res.result.result
										})

									})
								}
							})
						})
					}
				})
			},
			open() {
				// console.log('open');
			},
			close() {
				this.show = false
				// console.log('close');
			},
			//点击图标
			clickicon() {
				this.show = true

			},
			// 去详情页面
			goDetail(id) {
				uni.navigateTo({
					url: '/pages/detail/detail?id=' + id
				})
			},
			// tabs分类
			getTabs() {
				db.collection("zhen_cate").get().then(res => {
					console.log(res);
					this.tabs = res.result.data
					db.collection("zhen_indexarticle").where({
						category_id: res.result.data[0]._id
					}).get().then(res => {
						this.artList = res.result.data
					})
				})
			},
			// 获取轮播图
			getBanner() {
				db.collection("zhen_banner").get().then(res => {
					this.bannerList = res.result.data.map(item => {
						return item.bannerfile.url
					})
				})
			},
			click(item) {
				db.collection("zhen_indexarticle").where({
					category_id: item._id
				}).get().then(res => {
					this.artList = res.result.data
					console.log(this.artList);
				})
			}
		}
	}
</script>

<style>
	page {
		width: 100%;
		height: 100%;
		background-color: #F0EFF4;
	}
</style>