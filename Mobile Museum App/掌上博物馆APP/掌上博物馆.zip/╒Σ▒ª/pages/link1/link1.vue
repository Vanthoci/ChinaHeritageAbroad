<template>
	<view class="warp">
		<web-view :src="url"></web-view>
	</view>
</template>
<script>
	export default {
		data() {
			return {
				url: '',
			}
		},
		onShow() {
			let access_token = uni.getStorageSync('access_token');
			// 本地html文件
			this.url="/static/neo/2.html?access_token="  + access_token; 
			
			//网络链接地址
			//this.url = "http://m.hctech666.top/webview?access_token=" + access_token; 
			
		},
	}
</script>
