<template>
	<view>
		<web-view :webview-styles="webviewStyles" src="http://localhost:8000/connect_LLM/"></web-view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				webviewStyles: {
					progress: {
						color: '#FF3333'
					}
				}
			}
		}
	}
</script>

<style>

</style>
