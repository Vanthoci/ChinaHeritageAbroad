<template>
	<view>
		<view style="width: 95%;border-radius: 20rpx;height: 400rpx;margin: 20rpx auto;background-color: #fff;" class=" flex flex-column" v-for="(item,index) in list">
			<view style="flex: 3;">
				<image :src="item.avatar" style="width: 100%;height: 100%;"  mode=""></image>
			</view>
			<view style="flex: 1;">
				<view style="width: 90%;margin: 0 auto;">
					<view>
						<view><text>{{item.title}}|</text>{{item.content}}</view>
					</view>
					<view>
						<view><text>{{item.author}}</text></view>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	const db=uniCloud.database()
	export default {
		data() {
			return {
				list:[]
			}
		},
		onLoad() {
			this.getData()
		},
		methods: {
			// 获取数据
			getData(){
				db.collection("list_article").get().then(res=>{
					this.list=res.result.data
				})
			}
		}
	}
</script>

<style>
page {
		width: 100%;
		height: 100%;
		background-color: #F0EFF4;
	}
</style>
