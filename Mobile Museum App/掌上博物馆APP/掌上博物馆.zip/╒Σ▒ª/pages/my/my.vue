<template>
	<view>
		<view style="height: 270rpx;background-color: #AC9162;" class="flex flex-column justify-end">
			<view class="ml-5 flex justify-between mb-5">
				<view style="display: flex;align-items: center;">
					<image src="../../static/logo.png" style="width: 100rpx;height: 100rpx;border-radius: 100%;"
						mode=""></image>
					<text class="ml-3 text-white" @click="goLgoin">{{username?username:'登入'}}</text>
				</view>

				<u-icon label="" size="25" name="bell" color="#fff" class="mr-4"></u-icon>

			</view>
		</view>
		<view
			style="width: 100%;margin: 20rpx auto;background-color: #fff;display: flex;align-items: center;border-radius: 20rpx;height: 120rpx;">
			<u-icon label="" size="40" name="level" style="margin-left: 20rpx;"></u-icon>
			<view class="font-md ml-5" v-if="username=='admin'">
				管理员
			</view>
			<view class="font-md ml-5" v-else>
				普通用户
			</view>
		</view>
		<view class="bg-white">
			<u-cell-group v-for="(item,index) in cellList" :key="index">
				<u-cell size="large" :title="item.name" isLink :icon="item.icon" @click="outLogin(index)" :value="item.value"></u-cell>
			</u-cell-group>
		</view>
		
		<view
			style="width: 80%;background-color: #AC9162;margin: 0 auto;color: #fff;height: 70rpx;display: flex;align-items: center;justify-content: center;border-radius: 25rpx;margin-top: 30rpx;"
			@click="createAccount">
			创建账号
		</view>
	</view>
</template>

<script>
	const db=uniCloud.database()
	export default {
		data() {
			return {
				cellList: [{
						name: '问题中心',
						icon: 'question'
					},
					{
						name: '观看历史',
						icon: 'order'
					},
					{
						name: '发布动态',
						icon: 'file-text',
						value:this.score
					},
					{
						name: '设置中心',
						icon: 'setting'
					},
					{
						name: '退出登入'
					}
				],
				uid: '',
				token: '',
				username: '',
				uid: '',
				vip: '',
				score:0
			}
		},
		onLoad() {
			uni.getStorage({
				key: 'uni_id_token',
				success: (res) => {
					console.log(res)
					this.token = res.data
				}
			});
			uni.getStorage({
				key: 'uni-id-pages-userInfo',
				success: res => {
					this.uid = res.data._id
					this.username = res.data.username
				}
			});
			this.getScore()
			
		},
		methods: {
			getScore(){
				db.collection("uni-id-users").doc(this.uid).field("score").get().then(res=>{
					this.score=res.result.data[0].score
				})
			},
			//退出登入
			outLogin(index) {
				switch (index) {
					case 1:
					if (this.username !== 'admin') {
						uni.showModal({
							title: '您的权限不够'
						})
						return
					}
						uni.navigateTo({
							url: '/pages/mineSet/userRun/userRun'
						})
						break;
					case 2:
						uni.navigateTo({
							url:'/pages/publish/publish'
						})
						break;
					case 4:
						uni.showModal({
							title: '确定退出登入吗',
							success: (res) => {
								if (res.confirm == true) {
									uni.clearStorage()
									setTimeout(() => {
										uni.navigateTo({
											url: '/uni_modules/uni-id-pages/pages/login/login-withpwd'
										})
									}, 800)
								}
							}
						})
						break;
					default:
						break;
				}
			},
			// 创建账号
			createAccount() {
				uni.navigateTo({
					url: '/uni_modules/uni-id-pages/pages/register/register'
				})
			},
			// 登入
			goLgoin() {
				if(this.token){
					return
				}else{
					uni.navigateTo({
					url: '/uni_modules/uni-id-pages/pages/login/login-withpwd'
				})
				}
				
			}
		}
	}
</script>

<style>

</style>