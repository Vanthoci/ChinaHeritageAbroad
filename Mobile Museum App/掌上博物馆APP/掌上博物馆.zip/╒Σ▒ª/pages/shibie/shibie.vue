<template>
	<view>
		<helang-compress ref="helangCompress"></helang-compress>
		<view v-show="show" style="font-size: 80rpx;height: 500rpx;" class="flex align-center justify-center">
			暂无图片
		</view>
		<view @click="goDetail(list)" v-show="listArticle.title">
			<image :src="imgurl" mode="" style="width: 100%;border-radius: 20rpx;" ></image>
			<view>
				{{listArticle.title}}
			</view>
		</view>
	</view>
</template>

<script>
	import helangCompress from '@/components/helang-compress/helang-compress';
	const db=uniCloud.database()
	export default {
		components: {
			helangCompress
		},
		data() {
			return {
				title: 'Hello',
				list:[],
				imgurl:'',
				listArticle:{},
				show:false
			}
		},
		onLoad() {
			this.shebieSrc()
		},
		methods: {
			shebieSrc(){
				uni.chooseImage({
					count:1,
					success: (res) => {
						console.log(res.tempFiles[0].path);
						uniCloud.uploadFile({
							cloudPath:res.tempFiles[0].name,
							filePath:res.tempFiles[0].path
						}).then(res=>{
							console.log(res.fileID);
							uniCloud.callFunction({
											name: "userCImage",
											data: {
												image:res.fileID
											}
										}).then(res => {
											console.log(res);
											if(res.result.result_num==0){
												this.show=true
											}
											this.list=res.result.result[0].brief
											console.log(this.list);
											db.collection("zhen_indexarticle").doc(this.list).get({
												getOne:true
											}).then(res=>{
												console.log(res);
												this.listArticle=res.result.data
											})
											
											
													
										})
										this.imgurl=res.fileID
						})
						
					}
				})
			},
			goDetail(id){
			uni.navigateTo({
				url:'/pages/detail/detail?id='+id
			})	
			},
			// shebieSrc() {
			// 	let vm = this;
			// 	uni.chooseImage({
			// 		count: 1,
			// 		success: function(resq) {
			// 			let filePath = resq.tempFilePaths[0]
			// 			console.log(filePath);
			// 			uniCloud.callFunction({
			// 				name: "userCImage",
			// 				data: {
			// 					image: filePath
			// 				}
			// 			}).then(res => {
			// 				console.log(res);
							
									
			// 			})
			// 			return
			// 			vm.$refs.helangCompress.compress({
			// 				src: filePath,
			// 				maxSize: 100,
			// 				fileType: 'jpg',
			// 				quality: 0.1,
			// 				minSize: -1
			// 			}).then(resp => {
			// 				uni.request({
			// 					url: resp,
			// 					method: 'GET',
			// 					responseType: 'arraybuffer',
			// 					success: function(res) {
			// 						let base64s = uni.arrayBufferToBase64(res.data);
			// 						uniCloud.callFunction({
			// 							name: "userCImage",
			// 							data: {
			// 								bas64: base64s
			// 							}
			// 						}).then(res => {
			// 							console.log(res);
										
			
			// 						})
			// 					}
			// 				})
			// 			})
			// 		}
			// 	})
			// }
		}
	}
</script>

<style>

</style>
