// app.js

// 设置Neo4j API端点
const url = 'http://47.97.252.85:7474/db/neo4j/tx/commit';
const username = 'neo4j';
const password = 'neo4j';

// 设置HTTP请求头
const headers = new Headers({
  'Authorization': 'Basic ' + btoa(username + ':' + password),
  'Content-Type': 'application/json'
});

async function fetchRelatedEdges(itemName) {
  // Cypher查询，寻找所有与特定藏品名相关的边
  const query = {
    statements: [{
      statement: `
          MATCH (n {name: $itemName})
          WITH n
          LIMIT 1
          MATCH (n)-[r]-(m)
          RETURN n, type(r), m
          LIMIT 10
        `,
      parameters: {
        itemName: itemName
      }
    }]
  };

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: headers,
      body: JSON.stringify(query)
    });
    const data = await response.json();
    if (data.errors && data.errors.length > 0) {
      console.error('查询错误:', data.errors);
      return null; // 如果有错误，返回null或适当的错误处理
    } else {
      console.log('查询结果:', data.results[0].data);
      return data.results[0].data; // 返回查询结果
    }
  } catch (error) {
    console.error('请求错误:', error);
    return null; // 在捕获到错误时返回null或适当的错误处理
  }
}


function stringToColor(seed) {
  //一个简单的哈希函数，将字符串转换为一个数值
  // function hashCode(str) {
  //     var hash = 0;
  //     for (var i = 0; i < str.length; i++) {
  //         var char = str.charCodeAt(i);
  //         hash = ((hash << 5) - hash) + char;
  //         hash = hash & hash; // Convert to 32bit integer
  //     }
  //     return hash;
  // }

  // // 将哈希值转换为颜色，并保证颜色的亮度较高
  // function intToBrightRGB(hash) {
  //     var r = (hash & 0xFF0000) >> 16;
  //     var g = (hash & 0x00FF00) >> 8;
  //     var b = hash & 0x0000FF;

  //     // 保证颜色的亮度较高，通过增加每个颜色分量的值
  //     var brightnessFactor = 72; // 亮度因子，范围从 0 到 255
  //     r = Math.min(r + brightnessFactor, 255);
  //     g = Math.min(g + brightnessFactor, 255);
  //     b = Math.min(b + brightnessFactor, 255);

  //     return "#" + ("00" + r.toString(16)).slice(-2) + ("00" + g.toString(16)).slice(-2) + ("00" + b.toString(16)).slice(-2);
  // }

  // var hash = hashCode(seed);
  // var color = intToBrightRGB(hash);
  // 输出结果
  //console.log(color);
  var colors = ["#FFC454", "#4C8EDA", "#F16667", "#C990C0", "#ECB5C9", "#57C7E3", "#F79767", "#D9C8AE", "#8DCC93"];
  //var colors = ["#fcc515","#f7e8aa","#e8b004","#f9c116","#f9d770","#fbc82f","#f1f0ed"];
  //var colors=["#e4bf11","#d2b116","#fbda41","#eed045","#f1ca17","#d2b42c","#f2ce2b"];
  var labels = ["制造于", "来源为", "类型为", "收藏等级为", "位于", "创作者为", "材质为"];
  for (let i = 0; i < labels.length; i++) {
    if (labels[i] === seed) {
      var color = colors[i];
      break;
    }
  }
  return color;
}

function renderNetwork(graphData) {
  const container = document.getElementById('mynetwork'),
    data = { nodes: new vis.DataSet(graphData.nodes), edges: new vis.DataSet(graphData.edges) },
    options = {
      nodes: { shape: 'circle', borderWidth: 3, },
      edges: { arrows: 'to', font: { align: 'top', size: 12 }, labelHighlightBold: true, smooth: { type: 'continuous' } }, interaction: { hover: true }
    },
    network = new vis.Network(container, data, options);
  // network.on("click", params => { if (params.nodes.length > 0) { const node = graphData.nodes.find(n => n.id === params.nodes[0]); if (node.url) window.open(node.url, '_blank'); } });
  network.on("click", function (params) {
    console.log("GG");
    if (params.nodes.length > 0) {
      const nodeId = params.nodes[0];
      const node = data.nodes.get(nodeId);
      // alert('Clicked node: ' + node.label);
      processData(node.label);
    }
  });
}

function dataToGraph(datarows) {
  // 初始化图的节点和边数组
  const graph = {
    nodes: [],
    edges: []
  };

  // 使用一个映射来记录所有独特的节点和它们的ID
  const nodeMap = {};

  // 为每个条目生成节点和边
  datarows.forEach((entry, index) => {
    let innerId = 0, outerId = 2;
    if ('id' in entry.row[outerId]) {
      outerId = 0, innerId = 2
    }

    const centerNode = entry.row[innerId];
    const relationship = entry.row[1];
    //console.log(relationship);
    const relatedNode = entry.row[outerId];


    // 检查中心节点是否已经在图中
    if (!nodeMap.hasOwnProperty(centerNode.id)) {
      nodeMap[centerNode.id] = {
        id: centerNode.name,
        label: `${centerNode.name}`,
        widthConstraint: 70,
        color: "#f8d86a",
      };
      graph.nodes.push(nodeMap[centerNode.id]);
    }

    // 创建或确认相关节点
    if (relatedNode && relatedNode.name) {
      const relatedNodeId = `${relatedNode.name}`; // 生成唯一ID
      console.log(relationship);
      if (!nodeMap.hasOwnProperty(relatedNodeId)) {
        nodeMap[relatedNodeId] = {
          id: relatedNodeId,
          label: `${relatedNode.name}`,
          font: { color: "white" },
          widthConstraint: 70,
          color: stringToColor(relationship),
        };
        graph.nodes.push(nodeMap[relatedNodeId]);
      }

      // 创建边
      graph.edges.push({
        from: nodeMap[centerNode.id].id,
        to: nodeMap[relatedNodeId].id,
        label: relationship,
        length: 200,
        color: "#A5ABB6",
      });
    }
  });

  return graph;
}

async function processData(name) {
  const datarows = await fetchRelatedEdges(name);
  // 示例使用
  const graphData = dataToGraph(datarows);

  renderNetwork(graphData);

}

processData('清光绪通宝铜钱').catch(error => console.error('处理数据时发生错误:', error));

document.getElementById("myForm").addEventListener("submit", function (event) {
  event.preventDefault(); // 阻止表单的默认提交行为
  var input = document.getElementById("myInput"); // 获取输入框元素节点
  var inputVal = input.value; // 获取输入框的值
  console.log(inputVal); // 输出输入框的值
  processData(inputVal).catch(error => console.error('处理数据时发生错误:', error));
});