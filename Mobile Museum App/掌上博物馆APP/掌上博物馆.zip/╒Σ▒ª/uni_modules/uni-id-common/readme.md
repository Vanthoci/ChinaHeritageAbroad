# uni-id-common

文档请参考：[uni-id-common](https://uniapp.dcloud.net.cn/uniCloud/uni-id-common.html)