module.exports = {
  getSupportedLoginType: require('./get-supported-login-type')
}
