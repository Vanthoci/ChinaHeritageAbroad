/** uni-admin 缓存键名 */
export const uniAdminCacheKey = {
	theme: "uni-admin-theme", // 主题

}
